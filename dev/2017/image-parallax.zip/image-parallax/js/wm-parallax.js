jQuery(document).ready(function ($) {
  'use strict';
  $('.wm-parallax ul').each(function () { new Parallax(this); });
});
